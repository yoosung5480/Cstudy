#include <stdio.h>
#include <string.h>

int arr[128] = {0};
int alpha[26] = {0};

int main(){
    // 
    // arr[(int) temp]++;

    // for(int i = 'a'; i < 'z'; i++){
         
    // }
    char temp = 'a';
    alpha[temp - 'a'];

    printf("%d", 'b'-'a');
    printf("%c", 97);
    
    return 0;
}


